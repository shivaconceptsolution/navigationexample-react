import { Link, Outlet } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
function Master()
{
    return(<div className="container-fluid">
        <header>
        
         <nav className="navbar navbar-expand-sm">
         <div className="container-fluid">
  
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="collapsibleNavbar">
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link className="nav-link" to="/first">First</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/second">Second</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/third">Third</Link>
        </li>
      </ul>
    </div>
  </div>
</nav>
        </header>
        <section>
            <Outlet />
        </section>
        <footer>
            <center>&copy;2023 by SCS</center>
        </footer>
    </div>)
}

export default Master;