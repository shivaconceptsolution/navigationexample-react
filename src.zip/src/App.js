import './App.css';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import FirstComponent from './FirstComponent';
import SecondComponent from './SecondComponent';
import ThirdComponent from './ThirdComponent';
import Master from './Master';
import AdminMaster from './admincomponents/AdminMaster';
import AdminFirstComponent from './admincomponents/AdminFirstComponent';
import AdminSecondComponent from './admincomponents/AdminSecondComponent';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Master />}>
       <Route index element={<FirstComponent />} />
       <Route path="first" element={<FirstComponent />} />
       <Route path="second" element={<SecondComponent />} />
       <Route path="third" element={<ThirdComponent />} />
     </Route>
     <Route path="/admin" element={<AdminMaster />}>
       <Route index element={<AdminFirstComponent />} />
       <Route path="adminfirst" element={<AdminFirstComponent />} />
       <Route path="adminsecond" element={<AdminSecondComponent />} />
      
     </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
