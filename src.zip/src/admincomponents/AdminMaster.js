import { Link, Outlet } from "react-router-dom";

function AdminMaster()
{
    return(<div>
        <header>
           <ul>
            <li><Link to="/admin/adminfirst">First </Link></li>
            <li><Link to="/admin/adminsecond">Second </Link></li>
           </ul>
        </header>
        <section>
           <Outlet />
        </section>
        <footer>

        </footer>
    </div>)
}

export default AdminMaster;