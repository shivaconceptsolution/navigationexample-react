function AdminSecondComponent()
{
    return(<div>
        <h1>This is second component of Admin</h1>
    </div>)
}
export default AdminSecondComponent;