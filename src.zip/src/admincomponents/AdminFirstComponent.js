function AdminFirstComponent()
{
    return(<div>
        <h1>This is first component of Admin</h1>
    </div>)
}
export default AdminFirstComponent;