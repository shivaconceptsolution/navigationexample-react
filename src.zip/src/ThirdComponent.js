function ThirdComponent()
{
    return(<div>
        <h1>Third Component of Guest</h1>
    </div>)
}
export default ThirdComponent;