function FirstComponent()
{
    return(<div className="container-fluid">
        <h1>First Component of GUEST</h1>
        <div className="row">
            <div className="col-sm-4">
                <h1>part1</h1>
            </div>
            <div className="col-sm-8">
                <h2>part2</h2>
            </div>
        </div>
        
    </div>)
}
export default FirstComponent;