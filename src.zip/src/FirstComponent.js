import banner from "./a.png";
function FirstComponent()
{
    return(<div className="container-fluid">
        <h1>First Component of GUEST</h1>
        <div className="row">
            <div className="col-sm-4">
                
                <img src="a.jpg" className="img-fluid rounded-circle" alt="A" />
            </div>
            <div className="col-sm-8">
            <img src={banner} className="img-fluid" alt="A" />
            </div>
        </div>
        
    </div>)
}
export default FirstComponent;